<?php
    $dsn = "mysql:host=localhost;charset=utf8;dbname=db01;";
    $pdo = new PDO($dsn, "admin", "1234");

?>