<?php
// 引入資料庫連接文件
include_once('./db.php');

// 確保 POST 請求中有必要的資料
if (isset($_POST['action']) && isset($_POST['id'])) {
    $action = $_POST['action'];
    $id = $_POST['id'];
    
    // 根據 action 來決定更新的內容
    if ($action === 'carousel') {
        // 取得 carousel 相關的資料
        $title = $_POST['title'];
        $text = $_POST['text'];
        
        // 處理圖片上傳
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $imageName = $_FILES['image']['name'];
            $imageTmpName = $_FILES['image']['tmp_name'];
            $imagePath = "../uploads/" . $imageName;
            move_uploaded_file($imageTmpName, $imagePath);
        }

        // 更新資料庫
        $stmt = $pdo->prepare("UPDATE carousel SET title = :title, text = :text, img = :img WHERE id = :id");
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':text', $text);
        $stmt->bindParam(':img', $imagePath);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
        }
    } elseif ($action === 'tickets') {
        // 取得 tickets 相關的資料
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];

        // 更新資料庫
        $stmt = $pdo->prepare("UPDATE tickets SET firstname = :firstname, lastname = :lastname, phone = :phone, password = :password WHERE id = :id");
        $stmt->bindParam(':firstname', $firstname);
        $stmt->bindParam(':lastname', $lastname);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
        }
    } elseif ($action === 'performance') {
        // 取得 performance 相關的資料
        $title = $_POST['title'];
        $date = $_POST['date'];
        $location = $_POST['location'];
        $description = $_POST['description'];

        // 更新資料庫
        $stmt = $pdo->prepare("UPDATE performance SET title = :title, date = :date, location = :location, description = :description WHERE id = :id");
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>
