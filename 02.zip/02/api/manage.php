<?php
header("Content-Type: application/json");
include("./db.php");

$response = ["status" => "error", "data" => []];

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $table = "";

    switch ($action) {
        case 'carousel':
        case 'performance':
            $table = $action;
            $sql = "SELECT id, img, title, text FROM $table";
            break;
        case 'tickets':
            $sql = "SELECT id, firstname, lastname, phone, password FROM tickets";
            break;
        default:
            echo json_encode($response);
            exit;
    }

    try {
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $response = ["status" => "success", "data" => $data];
    } catch (PDOException $e) {
        $response["error"] = $e->getMessage();
    }
}

echo json_encode($response);
?>
