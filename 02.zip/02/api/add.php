<?php
// 引入資料庫連接文件
include_once('../db.php');

// 檢查是否有 POST 資料
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    // 根據不同的 action 來處理
    switch ($action) {
        case 'carousel':
            // 取得 Carousel 相關的資料
            $img = $_POST['img'];
            $title = $_POST['title'];
            $text = $_POST['text'];

            // 新增資料庫
            $stmt = $pdo->prepare("INSERT INTO carousel (img, title, text) VALUES (:img, :title, :text)");
            $stmt->bindParam(':img', $img);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':text', $text);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Carousel item added']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database insert failed']);
            }
            break;

        case 'performance':
            // 取得 Performance 相關的資料
            $img = $_POST['img'];
            $title = $_POST['title'];
            $text = $_POST['text'];

            // 新增資料庫
            $stmt = $pdo->prepare("INSERT INTO performance (img, title, text) VALUES (:img, :title, :text)");
            $stmt->bindParam(':img', $img);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':text', $text);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Performance item added']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database insert failed']);
            }
            break;

        case 'tickets':
            // 取得 Tickets 相關的資料
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $phone = $_POST['phone'];
            $password = $_POST['password'];

            // 新增資料庫
            $stmt = $pdo->prepare("INSERT INTO tickets (firstname, lastname, phone, password) VALUES (:firstname, :lastname, :phone, :password)");
            $stmt->bindParam(':firstname', $firstname);
            $stmt->bindParam(':lastname', $lastname);
            $stmt->bindParam(':phone', $phone);
            $stmt->bindParam(':password', $password);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Ticket added']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database insert failed']);
            }
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            break;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>
