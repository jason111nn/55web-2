<?php
require_once('db.php'); // 引入資料庫連線檔案

// 確認是否有接收到必要的參數
if (isset($_POST['action']) && isset($_POST['id'])) {
    $action = $_POST['action'];
    $id = $_POST['id'];

    // 根據 action 決定要刪除的資料表
    $table = "";
    if ($action === "carousel") {
        $table = "carousel";
    } else if ($action === "tickets") {
        $table = "tickets";
    } else if ($action === "performance") {
        $table = "performance";
    }

    // 檢查資料表是否設定
    if ($table !== "") {
        // 建立 SQL 刪除語句
        $sql = "DELETE FROM $table WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);

        // 執行刪除操作
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
}
?>
